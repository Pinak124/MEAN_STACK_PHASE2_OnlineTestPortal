import { Question.Model } from './question.model';

describe('Question.Model', () => {
  it('should create an instance', () => {
    expect(new Question.Model()).toBeTruthy();
  });
});
