export class Question {
    constructor(public questions:string,public question:string,public answers:Array<string>,public correct:string){}
}
